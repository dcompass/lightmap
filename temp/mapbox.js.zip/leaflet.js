module.exports = window.L = require('./leaflet-src');
