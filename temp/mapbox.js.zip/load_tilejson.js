'use strict';

var request = require('./request'),
    format_url = require('./format_url'),
    util = require('./util');

module.exports = {
    _loadTileJSON: function(_) {
        if (typeof _ === 'string') {
if(_==''){
  this.shareControl._setTileJSON();
 this._mapboxLogoControl._setTileJSON();
return this.fire('ready');
}

            _ = format_url.tileJSON(_, this.options && this.options.accessToken);
            request(_, L.bind(function(err, json) {
                if (err) {
                   // util.log('could not load TileJSON at ' + _);
                   // this.fire('error', {error: err});
                    this.fire('ready');
                } else if (json) {
                    this._setTileJSON(json);
                    this.fire('ready');
                }
            }, this));
        } else if (_ && typeof _ === 'object') {
            this._setTileJSON(_);
        }
    }
};
