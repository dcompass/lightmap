module.exports = require('./lib/client/index');
